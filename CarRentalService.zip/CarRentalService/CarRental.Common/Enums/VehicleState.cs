﻿namespace CarRental.Common.Enums;

public enum VehicleTypes
{
    
}
