﻿
using System.Runtime.InteropServices.JavaScript;
using CarRental.Common.Enums;
using CarRental.Common.Interfaces;

namespace CarRental.Data.Interfaces;

public interface IData
{
    IEnumerable<IPerson> GetPersons();
    IEnumerable<IVehicle> GetVehicles(VehicleStatuses status = default)
    IEnumerable<IBooking> GetBookings();

    IPerson GetPersons(string, SSN);
    IPerson GetPersons(int id);
    IBooking GetBookking(int, vehicled);
    IVehicle GetVehicle(string, REgNo)
    IVehicle GetVehicle(int 
        
        );