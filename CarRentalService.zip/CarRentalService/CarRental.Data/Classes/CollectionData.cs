﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Intrinsics.X86;
using System.Text;
using System.Threading.Tasks;

namespace CarRental.Data.Classes
{
    internal class CollectionData
    {
    }
}

SSN Last Name	First Name
12345	Doe	John
98765	Doe	Jane



RegNo	Make	Odometer	Cost Km	Vehicle Type	$ Day	Status
ABC123	Volvo	100000	1	Combi	200	Available
DEF456	Saab	200000	1	Sedan	100	Available
GHI789	Tesla	1000	3	Sedan	100	Booked
JKL012	Jeep	5000	1.5	Van	300	Available
MNO234	Yamaha	300000	0.5	Motorcycle	50	Available